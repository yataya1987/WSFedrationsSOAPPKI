﻿namespace SampleService2.Models
{
    public class Order
    {
        public int Id { get; set; }
        public decimal Price { get; set; }
    }
}