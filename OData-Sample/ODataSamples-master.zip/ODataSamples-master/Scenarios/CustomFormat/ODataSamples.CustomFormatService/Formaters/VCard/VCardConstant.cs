﻿namespace ODataSamples.CustomFormatService.Formaters.VCard
{
    internal class VCardConstant
    {
        public const string Begin = "BEGIN:VCARD";
        public const string End = "END:VCARD";
    }
}
