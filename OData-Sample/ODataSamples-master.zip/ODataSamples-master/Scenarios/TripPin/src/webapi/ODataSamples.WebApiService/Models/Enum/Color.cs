﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ODataSamples.WebApiService.Models.Enum
{
    public enum Color
    {
        Red,
        Green,
        Blue,
        Yellow,
        Pink,
        Purple
    }
}