Execute the following command before debugging into this project:
msiexec VSEXTUI=1 /I \\cpvsbuild\drops\dev14\ProjectKRel\layouts\x86ret\current\enu\netfx\coreruntimesdk\net\netfx_CoreRuntimeSDK.msi