﻿using System.Web;
using System.Web.Http;

namespace AdventureWorksLTSample
{
    public class WebApiApplication : HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
        }
    }
}
