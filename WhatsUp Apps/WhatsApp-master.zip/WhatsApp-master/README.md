# WhatsApp

## Preview
![Imgur](https://i.imgur.com/osYOf5y.png)

## Description
This is a simple WhatsApp rip-off, it's merely intended for experimentation, no production goals are planned, no real-time updates aswell, refreshing the forms will be a great task to update the messages and pop ups.

## Features
- [X] Creating accounts.
- [X] Total control over accounts (Avatar, username, status...).
- [X] Theme customazation.
- [X] Ability to add/block people to/from your contact list.
- [X] Emoji board.
- [X] Data saving (*ofcourse*)
