- Other numer | You bot

![](videobot.gif)


# Instructions

- Put 'dan.zip'file in debug folder 
- Press 1 in console
- Scan QR Code
- After scan QR Code press Enter
- To test: send a message that you use to scan, to try pokemon send the message -> / pokemon 3


# WebWhatsappBot

- You will NOT use this API for marketing purposes (spam, massive sending...).
- We do NOT give support to anyone that wants this API to send massive messages or similar.
- We reserve the right to block any user of this repository that does not meet these conditions.

# Changelog v1.1
- Using mongo to save messages (is optional)
- Greater performance to detect new messages
- Creation of groups

Commands added:

- / pokemon 31
- / group -name of group -2211111111 2211111111

This first command returns a pokemon name, the second command creates a group


# License
WebWhatsappBot is released under the MIT license. See [License](https://github.com/ZetDeveloper/WebWhatsappBot/blob/master/LICENSE) for details.
