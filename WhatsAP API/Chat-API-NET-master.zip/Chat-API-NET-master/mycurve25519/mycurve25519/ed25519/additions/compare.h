#ifndef __COMPARE_H__
#define __COMPARE_H__

int crypto_verify_32_ref(const unsigned char *b1, const unsigned char *b2);

#endif
