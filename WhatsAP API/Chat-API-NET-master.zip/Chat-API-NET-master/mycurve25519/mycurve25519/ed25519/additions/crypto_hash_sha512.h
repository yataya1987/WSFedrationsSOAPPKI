#ifndef crypto_hash_sha512_H
#define crypto_hash_sha512_H

extern int crypto_hash_sha512(unsigned char *,const unsigned char *,unsigned long long);

#endif
