#ifndef crypto_uint64_h
#define crypto_uint64_h

typedef unsigned long long crypto_uint64;

#endif
