Chat API .NET (Project not longer maintained)
===========

This is an API written in C# but it can be used in any .NET language. It's a fork from WhatsAPINet, which is based on Chat API (php).

## Documentation
* FunXMPP Protocol - https://github.com/mgp25/Chat-API/wiki/FunXMPP-Protocol

## Protocol
More info in Chat API repo wiki https://github.com/mgp25/Chat-API

**Special thanks to [shirioko](https://github.com/shirioko)**

# Terms and conditions

- You will NOT use this API for marketing purposes (spam, massive sending...).
- We do NOT give support to anyone that wants this API to send massive messages or similar.
- We reserve the right to block any user of this repository that does not meet these conditions.
