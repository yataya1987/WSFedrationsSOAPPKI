var searchData=
[
  ['load',['Load',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a6e8b8b0fbf62bffb3e153f4003280626',1,'WebWhatsappAPI::BaseClass']]]
];
