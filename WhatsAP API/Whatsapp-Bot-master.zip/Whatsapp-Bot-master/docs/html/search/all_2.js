var searchData=
[
  ['chatsettings',['ChatSettings',['../class_web_whatsapp_a_p_i_1_1_base_class_1_1_chat_settings.html',1,'WebWhatsappAPI::BaseClass']]],
  ['chromewapp',['ChromeWApp',['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html',1,'WebWhatsappAPI.Chrome.ChromeWApp'],['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#a9c8ebf61ff410da72e8a50d68cbcf0f5',1,'WebWhatsappAPI.Chrome.ChromeWApp.ChromeWApp()']]]
];
