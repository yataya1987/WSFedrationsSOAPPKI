var searchData=
[
  ['base64toimage',['Base64ToImage',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a3c18dac86c5b0a57ebfb1822e89518d8',1,'WebWhatsappAPI::BaseClass']]]
];
