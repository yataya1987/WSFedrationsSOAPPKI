var searchData=
[
  ['firefoxwapp',['FirefoxWApp',['../class_web_whatsapp_a_p_i_1_1_firefox_1_1_firefox_w_app.html#a0c7a2248a6cf1699443a3ec99a17ba6d',1,'WebWhatsappAPI::Firefox::FirefoxWApp']]]
];
