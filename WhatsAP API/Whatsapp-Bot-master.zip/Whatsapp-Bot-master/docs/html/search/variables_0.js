var searchData=
[
  ['settings',['settings',['../class_web_whatsapp_a_p_i_1_1_base_class.html#af7b5c73d834b7c97f6aa1947310af34e',1,'WebWhatsappAPI::BaseClass']]]
];
