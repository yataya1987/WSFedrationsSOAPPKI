var searchData=
[
  ['addextension',['AddExtension',['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#aaf4df519b4cda569bbb8f6d757a372f2',1,'WebWhatsappAPI::Chrome::ChromeWApp']]],
  ['addextensionbase64',['AddExtensionBase64',['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#a6a01da1da6329da843cbed002716ea36',1,'WebWhatsappAPI::Chrome::ChromeWApp']]],
  ['addstartargument',['AddStartArgument',['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#a4dd7c9e90b65a5c3fdbb7d0b12f4823c',1,'WebWhatsappAPI::Chrome::ChromeWApp']]],
  ['autosave',['AutoSave',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a56a2f1cfc0bef6cad2aae521e9c4d20a',1,'WebWhatsappAPI::BaseClass']]],
  ['autosavesettings',['AutoSaveSettings',['../class_web_whatsapp_a_p_i_1_1_base_class_1_1_auto_save_settings.html',1,'WebWhatsappAPI::BaseClass']]]
];
