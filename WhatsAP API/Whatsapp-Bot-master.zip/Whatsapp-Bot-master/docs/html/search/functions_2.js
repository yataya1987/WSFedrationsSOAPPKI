var searchData=
[
  ['chromewapp',['ChromeWApp',['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#a9c8ebf61ff410da72e8a50d68cbcf0f5',1,'WebWhatsappAPI::Chrome::ChromeWApp']]]
];
