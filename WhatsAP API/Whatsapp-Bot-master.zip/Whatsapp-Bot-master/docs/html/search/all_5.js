var searchData=
[
  ['getlastesttext',['GetLastestText',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a9b62276c558e7e81cf507af854cdc0b2',1,'WebWhatsappAPI::BaseClass']]],
  ['getqrimage',['GetQRImage',['../class_web_whatsapp_a_p_i_1_1_base_class.html#ac9738e95307e38b1ef493c1164edb60c',1,'WebWhatsappAPI::BaseClass']]],
  ['getqrimageraw',['GetQRImageRAW',['../class_web_whatsapp_a_p_i_1_1_base_class.html#ad181052c89c24e15d53aa81c1afe531c',1,'WebWhatsappAPI::BaseClass']]]
];
