var searchData=
[
  ['messagescanner',['MessageScanner',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a1da111623bfd6bee9401b049560e2646',1,'WebWhatsappAPI::BaseClass']]]
];
