var searchData=
[
  ['eventdriver',['EventDriver',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a1db62394318cea6839e32f2820fb426f',1,'WebWhatsappAPI::BaseClass']]]
];
