var searchData=
[
  ['firefoxwapp',['FirefoxWApp',['../class_web_whatsapp_a_p_i_1_1_firefox_1_1_firefox_w_app.html',1,'WebWhatsappAPI::Firefox']]]
];
