var searchData=
[
  ['isphoneconnected',['IsPhoneConnected',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a8784fc769ca33afbbdb7478f0998de19',1,'WebWhatsappAPI::BaseClass']]]
];
