var indexSectionsWithContent =
{
  0: "abcefghilmopsw",
  1: "abcfmp",
  2: "fw",
  3: "abcfghilmos",
  4: "s",
  5: "ew",
  6: "w"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties",
  6: "Pages"
};

