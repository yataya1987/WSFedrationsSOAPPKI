var searchData=
[
  ['baseclass',['BaseClass',['../class_web_whatsapp_a_p_i_1_1_base_class.html',1,'WebWhatsappAPI']]]
];
