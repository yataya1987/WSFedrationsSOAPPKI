var searchData=
[
  ['autosavesettings',['AutoSaveSettings',['../class_web_whatsapp_a_p_i_1_1_base_class_1_1_auto_save_settings.html',1,'WebWhatsappAPI::BaseClass']]]
];
