var searchData=
[
  ['save',['Save',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a03ddf85cb437ebabb7f3444d856bd8a7',1,'WebWhatsappAPI::BaseClass']]],
  ['sendmessage',['SendMessage',['../class_web_whatsapp_a_p_i_1_1_base_class.html#a394d26a4172531e8149b5e084917dc99',1,'WebWhatsappAPI::BaseClass']]],
  ['settings',['settings',['../class_web_whatsapp_a_p_i_1_1_base_class.html#af7b5c73d834b7c97f6aa1947310af34e',1,'WebWhatsappAPI::BaseClass']]],
  ['startdriver',['StartDriver',['../class_web_whatsapp_a_p_i_1_1_base_class.html#aaa7e5947e31c9f475c95c9818f6c3a00',1,'WebWhatsappAPI.BaseClass.StartDriver(IWebDriver driver, string savefile)'],['../class_web_whatsapp_a_p_i_1_1_base_class.html#a8108d46b4176fc74fb49626e8122df88',1,'WebWhatsappAPI.BaseClass.StartDriver()'],['../class_web_whatsapp_a_p_i_1_1_base_class.html#a3a26ad50a4ba508f1162402bc00e128b',1,'WebWhatsappAPI.BaseClass.StartDriver(IWebDriver driver)'],['../class_web_whatsapp_a_p_i_1_1_chrome_1_1_chrome_w_app.html#a2ed5da636b9baf0766bd6804739a9bfb',1,'WebWhatsappAPI.Chrome.ChromeWApp.StartDriver()'],['../class_web_whatsapp_a_p_i_1_1_firefox_1_1_firefox_w_app.html#a80f406639e59bc4152b8f255962607f2',1,'WebWhatsappAPI.Firefox.FirefoxWApp.StartDriver()']]]
];
