# Whatsapp-Bot
Web.whatsapp.com bot made with selenium

[<img src="https://ci.appveyor.com/api/projects/status/github/IwraStudios/Whatsapp-Bot"></img>](https://ci.appveyor.com/project/IwraStudios/whatsapp-bot)

Documentation available in `Whatsapp-bot\docs`

and

https://iwrastudios.github.io/docs/Whatsapp-bot/

## Coming Soon
### To a pc near you

### TODO before (pre-)release
* Add more features
* Add more Drivers

# Terms and conditions

*  You will NOT use this API for marketing purposes (spam, massive sending...).
*  We do NOT give support to anyone that wants this API to send massive messages or similar.
*  We reserve the right to block any user of this repository that does not meet these conditions.
*  We are not associated with Whatsapp(tm).
*  I may have got this text from the Whatsapp API page sooooo: https://github.com/mgp25/Chat-API-NET
