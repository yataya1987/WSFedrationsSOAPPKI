package com.devexpress.efcoresecurity.efcoresecuritydemo.businessobjects;

/**
 * Created by neroslavskiy.a on 4/6/2016.
 */
public class ContactTask extends BaseSecurityEntity {
}
