﻿namespace Aldrigos.SmartSoap.Factories
{
    public interface ISoapClientFactory
    {
        ISoapClient Make();
    }
}
