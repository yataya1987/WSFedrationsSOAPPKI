﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aldrigos.SmartSoap.Test.DneModels
{
    public class AddResponse
    {
        public int AddResult { get; set; }
    }
}
