﻿using System;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace D2L.Security.OAuth2.Authorization {
	[AttributeUsage( AttributeTargets.Method, AllowMultiple = false )]
	public sealed class NoRequiredScopeAttribute : AuthorizeAttribute {
		// This attribute is only used as a signal in DefaultAuthorizationAttribute
		protected override bool IsAuthorized( HttpActionContext context ) {
			return true;
		}
	}
}
