﻿
namespace D2L.Security.OAuth2.Keys.Default {
	internal interface ISanePublicKeyDataProvider : IPublicKeyDataProvider { }
}
