# employee-dashboard
SPA - Angular 7.0 + ASP.NET CORE 2.1 + IdentityServer 4.0 + OIDC + ADFS 4.0
