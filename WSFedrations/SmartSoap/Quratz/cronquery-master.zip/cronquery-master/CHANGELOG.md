## [v1.1.0](https://github.com/logiqsystem/cronquery/releases/tag/v1.1.0) (2019-03-19)
### Features:
- Add support for `netcoreapp3.0.100-preview3-010431`
- Support for UTC offset to configure the time zone

## [v1.0.1](https://github.com/logiqsystem/cronquery/releases/tag/v1.0.1) (2019-02-12)
### Bug fixes:
- Ensure that second is reset when hour not match

## [v1.0.0](https://github.com/logiqsystem/cronquery/releases/tag/v1.0.0) (2019-01-05)
### Features:
- Recurring jobs using cron expressions
