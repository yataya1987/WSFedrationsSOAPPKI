﻿namespace Foundatio.Metrics {
    public class InMemoryMetricsClientOptions : SharedMetricsClientOptions { }

    public class InMemoryMetricsClientOptionsBuilder : SharedMetricsClientOptionsBuilder<InMemoryMetricsClientOptions, InMemoryMetricsClientOptionsBuilder> {}
}