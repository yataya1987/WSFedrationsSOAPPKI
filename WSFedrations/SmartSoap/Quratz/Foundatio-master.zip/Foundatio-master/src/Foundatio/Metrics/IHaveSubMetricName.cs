﻿namespace Foundatio.Metrics {
    public interface IHaveSubMetricName {
        string GetSubMetricName();
    }
}
