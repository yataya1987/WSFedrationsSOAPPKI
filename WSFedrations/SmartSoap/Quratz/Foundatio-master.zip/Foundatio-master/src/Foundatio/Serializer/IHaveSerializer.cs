﻿namespace Foundatio.Serializer {
    public interface IHaveSerializer {
        ISerializer Serializer { get; }
    }
}
