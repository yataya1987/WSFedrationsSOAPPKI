namespace Foundatio.Messaging {
    public class MessageBusData {
        public string Type { get; set; }
        public byte[] Data { get; set; }
    }
}