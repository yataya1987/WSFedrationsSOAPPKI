namespace Foundatio.Messaging {
    public class InMemoryMessageBusOptions : SharedMessageBusOptions { }

    public class InMemoryMessageBusOptionsBuilder : SharedMessageBusOptionsBuilder<InMemoryMessageBusOptions, InMemoryMessageBusOptionsBuilder> {}
}