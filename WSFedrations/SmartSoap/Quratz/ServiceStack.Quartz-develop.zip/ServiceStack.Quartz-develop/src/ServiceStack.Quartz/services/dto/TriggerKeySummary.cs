namespace ServiceStack.Quartz
{
    public class TriggerKeySummary
    {
        public string Group { get; set; }
        public string Name { get; set; }
    }
}