namespace ServiceStack.Quartz
{
    public class GetQuartzJobResponse
    {
        public JobSummary Job { get; set; }
    }
}