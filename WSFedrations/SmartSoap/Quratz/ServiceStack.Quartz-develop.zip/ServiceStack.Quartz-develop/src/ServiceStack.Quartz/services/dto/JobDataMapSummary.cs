namespace ServiceStack.Quartz
{
    public class JobDataMapSummary
    {
        public string Data { get; set; }
        public int Count { get; set; }
        public bool IsEmpty { get; set; }
        public bool Dirty { get; set; }
    }
}