namespace ServiceStack.Quartz
{
    public class GetQuartzJobsResponse
    {
        public JobSummary[] Jobs { get; set; }
    }
}