namespace ServiceStack.Quartz
{
    public class GetQuartzTriggerResponse
    {
        public TriggerSummary Trigger { get; set; }
    }
}