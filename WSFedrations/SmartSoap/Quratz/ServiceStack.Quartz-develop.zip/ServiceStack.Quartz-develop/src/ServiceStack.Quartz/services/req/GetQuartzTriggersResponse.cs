namespace ServiceStack.Quartz
{
    public class GetQuartzTriggersResponse
    {
        public TriggerKeySummary[] Triggers { get; set; }
    }
}