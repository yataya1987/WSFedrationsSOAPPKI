namespace ServiceStack.Quartz
{
    public class JobKeySummary
    {
        public string Group { get; set; }
        public string Name { get; set; }
    }
}